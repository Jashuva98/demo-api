
class QrcodeModel():
    search = 'title',
    value = 0
